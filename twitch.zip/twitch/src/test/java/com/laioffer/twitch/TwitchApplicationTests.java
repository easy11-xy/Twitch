package com.laioffer.twitch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TwitchApplicationTests {

	@Test
	void contextLoads() {
	}

}
