package com.laioffer.twitch.hello;

public record Book(
        String title,
        String author
) {
}
