package com.laioffer.twitch.model;

public enum ItemType {
    STREAM, VIDEO, CLIP
}

